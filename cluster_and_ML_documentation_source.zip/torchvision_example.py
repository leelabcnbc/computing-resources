# example using a torchvision network
# extracting some of its activations
import numpy as np
import torch
import matplotlib.pyplot as plt

from skimage.io import imread
from torchvision import transforms
from torchvision.models import resnet34

# download a small network for the example
# only downloads the weights the first time, only if you set pretrained=True
# these are trained on Imagenet, basically trustworthy that they're good
network = resnet34(pretrained=True)

# get an idea of what the object looks like
print(network)

# load in an example image
# diagram of an octopus brain -- they look quite weird
img = imread('octopus.jpg')
# the 224x224 size is necessary for most Imagenet-trained networks
print(img.shape)

# process the image before passing into the network
img = img[np.newaxis, ...].transpose(0, 3, 1, 2) # NCHW format
img = img / 255. # convert to 0-1 range
# these are the mean and standard deviation of Imagenet for each color
# always necessary to normalize by them for Torchvision models
# since they were trained on images with that normalization
normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std=[0.229, 0.224, 0.225])
img = normalize(torch.tensor(img).float())

# now, say we want to get intermediate responses from some middle conv layer
# setup a hook to do this
# the hook runs the function on arguments (module, input, output)
# each time the layer processes an input
int_responses = []
hook = network.layer3[1].conv2.register_forward_hook(
        lambda m, i, o: int_responses.append(o.data.cpu().numpy()))

# run the image through
# always use no_grad when not training to speed things up
with torch.no_grad():
    predictions = network(img)

# what does the network think this is?
print(predictions.argmax())
# 600 -- "hook, claw" -- well it wasn't trained on octopus brains

# remove the hook for cleanliness
hook.remove()

# and examine our activations
# not much spatial resolution at this stage in the resnet
int_responses = int_responses[0]
print(int_responses.shape)

# can look at one channel's activation as an image
# though it's not really enlightening
plt.figure()
plt.imshow(int_responses[0, 0])
plt.title('Intermediate conv layer response to octopus brain image')
plt.show()
