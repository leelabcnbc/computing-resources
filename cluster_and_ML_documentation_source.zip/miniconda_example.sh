# setting up an example miniconda environment
# after installing it according to website instructions
# the installed packages will take a fair amount of disk space
# maybe up to a gigabyte or so

# make and enter env -- good to have one of these for each project
# so you don't run into package version problems
# but it can be helpful to have a base package like this with general things
conda create -n basic_ml
source ~/.bashrc # not necessary outside of a script
conda activate basic_ml

# basics
conda install -c conda-forge numpy scipy matplotlib jupyterlab scikit-image
# ML stuff
conda install scikit-learn pytorch torchvision tensorflow

# and you're good to go
# can save the env to a file for easy replication
# though this has problems transferring between PC and Mac/Linux
conda env export > basic_ml.yml

# anyone with the file and conda can use the following line to install:
# conda env create -f basic_ml.yml
# although this may not transfer properly between mac/linux and windows
